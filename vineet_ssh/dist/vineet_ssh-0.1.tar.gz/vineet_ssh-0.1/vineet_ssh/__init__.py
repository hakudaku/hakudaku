from parallel import ssh_parallel
from serial import ssh_serial 
