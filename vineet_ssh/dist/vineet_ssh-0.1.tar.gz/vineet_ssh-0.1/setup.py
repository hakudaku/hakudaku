from distutils.core import setup
 
setup(name = "vineet_ssh",
      version = "0.1",
      description = "Allow to cluster ssh into multiple hosts",
      author = "Vineet Bhatia",
      author_email = "vbhatiav@yahoo.com",
      packages=["vineet_ssh"]
      )
